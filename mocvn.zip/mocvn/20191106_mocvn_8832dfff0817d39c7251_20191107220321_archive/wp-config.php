<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
//define('WP_CACHE', false); //Added by WP-Cache Manager
define( 'DB_NAME', '' );

/** MySQL database username */
define( 'DB_USER', '' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', '' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );
//* Authentication Unique Keys and Salts.

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'OYEP9k},v*~xMDP;m[Ql3m]uMoe^HJ]cv, fGe:Xt`~+>nW-4k3j<Y 0~Fmw[f~9');
define('SECURE_AUTH_KEY',  'IUcdesI)&Il<MOAs]mYBYG$%RM|law8J>d~-||~+<%nKbbrP?N(zh}g-^AVgBq-*');
define('LOGGED_IN_KEY',    'AR;dR+ty:#d:2QE gj43AgCW9gvLA-(x|j`_PGAvzkqfeJ+x;n9qOozJskfvd5BH');
define('NONCE_KEY',        '9N5q j7[smZ u%|B:f8t]#)uBYE0d-iKPKFP{[VOm%*2}>+oVy9~z)Gl+M|kV+z|');
define('AUTH_SALT',        '6lG=Rpq;E|J*D*;(pJGK>j28s^%21b]8[d|:e9h@}(^`AJkv++,9=S&}1NoD>?x@');
define('SECURE_AUTH_SALT', '~y!ZMy?[fp&6o+z25&n7h22UjJ7*S5N$C*$~FPf?8*a3hoQp7q`|uwRDgST~M7>z');
define('LOGGED_IN_SALT',   '[sW8:E*Qv|oAKM6Y(_EOs@)qhhbI3sW/FzD<p5)xzq$!cj)>TZqF>-+u8 lc^f(?');
define('NONCE_SALT',       'HEKTO-01Vz9=y}z+$v;m1RJpM+hCaSY[Y+S9ohHkMQ8sw+XhOtivT<DWVyW0V-9b');


/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
